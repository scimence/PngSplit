﻿namespace PngSplitFunc
{
    partial class PngSplit_mainForm
    {
        private static string StringDatas104 = "gegjhdhagphdgjgogh$hagbgogfgm$gmgjhdheecgphi$gdgpgohegfhiheengfgohffdhehcgjhadc$ofifkiojidkiofkplmofihlkoijcjjogjnlpfegpgpgmfdhehcgjhaengfgohfejhegfgn$ofifkiojidkiofkplmofihlkoijcjjogjnlp$ofkpljoflnjdofijinogiljgofifkfohjkieogijiaogjmijofjlloofidipoplmimogijkhoikbimofkplmofihlkoijcjjogjnlpogjdinoelnjm$oflhkgoeliikoflalkofkplioikdibofiiihfegpgpgmfdhehcgjhaengfgohfejhegfgn$oflhkgoeliikoflalkofkplioikdibofiiih$ofkpljoflnjdofijinogiljgofifkfohjkieogijiaogjmijofjlloofidipoplmimogijkhoikbimoflhkgoeliikoflalkofkplioikdibofiiih$ogjmiaojiaicoflalkofkplioikdibofiiihfegpgpgmfdhehcgjhaengfgohfejhegfgn$ogjmiaojiaicoflalkofkplioikdibofiiih$ofkpljoflnjdofijinogiljgofifkfohjkieogijiaogjmijofjlloofidipoplmimogijkhoikbimogjmiaojiaicofkplioikdibofiiih$hegpgpgmfdhehcgjhafdgfhagbhcgbhegphcde$ofjaiiofljlgoijcjjogjnlpofjlloofidipfegpgpgmfdhehcgjhaengfgohfejhegfgn$ofjaiiofljlgoijcjjogjnlpofjlloofidip$ofjmkioflnjdofijinogiljgofifkfohjkieogijiaogjmijofjlloofidipoilfieoglkjaoeliknoplmimogjajmohlekcogjikpofjakgoelilkofkplmofihlkoijcjjogjnlpofjlloofidipoplmimanakogjikpofiijjofjaiiofljlgdcoflmkagkhagfghoijcjjogjnlpofjlloofidipoplmimoelilkdboflmkaogjglaohjkiehagoghofjlloofidip$ogipjaofipjgoiloidoflaipoilfieoglkjafegpgpgmfdhehcgjhaengfgohfejhegfgn$ogipjaofipjgoiloidoflaipoilfieoglkja$ogiljgofifkfogijiaogjmijoplmiiofiojpofjlloofidipcaofjcimcaoijcjjogjnlpofjlloofidipoplmijoplmimoiihkkofikkiofkpljogkpjeoelkimoiiaifohjkieogjgihoelllgofkekhoflaipoplmimanakofkeinofiilgoiloidoflaipohjkieofjlloofidipoilfieoglkja$hegpgpgmfdhehcgjhafdgfhagbhcgbhegphcdf$ofkplmofihlkoelikeofiainoflalkofkplifegpgpgmfdhehcgjhaengfgohfejhegfgn$ofkplmofihlkoelikeofiainoflalkofkpli$hagjgdhehfhcgfecgphi$gdgpgohegfhiheengfgohffdhehcgjhadb$ofkplmofihlkogijiaogjmijofknjaofjllofegpgpgmfdhehcgjhaengfgohfejhegfgn$ofkplmofihlkogijiaogjmijofknjaofjllo$oflaigoflnjdofijinhagoghofjaiiofjlloofjlloofidipoplmimogimijojiaipogjiioofidipohlekaoplmimanakoiihkkofikkiofiiigofijlcoelilkoiilkfoelikkofknjaofjllocifegfhihehfhcgffagbgdglgfhcojiaigofkeieohjaigcj$ofkplmofihlkofknjaofjlloofimlkofjpjpfegpgpgmfdhehcgjhaengfgohfejhegfgn$ofkplmofihlkofknjaofjlloofimlkofjpjp$oflaigoflnjdofijinhagoghofjaiiofjlloofjlloofidipoplmimogimijojiaipogjiioofidipohlekaoplmimoiihkkofikkiofiiigofijlcoelilkoiilkfoelikkofknjaofjllooplmimanakofkplmofihlkofjaieofknjaofimlkofjpjpohjkieofimlkofjpjpoelpkbogibkpoelilkogjgihogjmkm$ofkplmofihlkohlcloohkoiaogjflaoginkofegpgpgmfdhehcgjhaengfgohfejhegfgn$ofkplmofihlkohlcloohkoiaogjflaoginko$oflaigoflnjdofijinhagoghofjaiiofjlloofjlloofidipoplmimogimijojiaipogjiioofidipohlekaoplmimoiihkkofikkiofiiigofijlcoelilkoiilkfoelikkofknjaofjllooplmimanakofkplmofihlkofjaieofknjaofimlkofjpjpohjkieofimlkofjpjpohlcloohkoiaoelpkbogibkpoelilkogjgihogjmkm$hegpgpgmfdhehcgjhafdgfhagbhcgbhegphcdc$ofkplmofihlkojibkoohlnkjofjlloofidipfegpgpgmfdhehcgjhaengfgohfejhegfgn$ofkplmofihlkoijcjjogjnlp$oflaigoflnjdofijinofimifofjaklojiaipogjiiooflkkgoelpkbogibkpohjkieofjlloofidipoplmimofiiigoikhkdoelilkoelikeoflmkagkhagfghoijcjjogjnlpofjlloofidip$ofkplmofihlkofjlloofidipfegpgpgmfdhehcgjhaengfgohfejhegfgn$ofkplmofihlkofjlloofidip$oelilkoijcjjogjnlpofjlloofidipfpdbcogkhagfghoglhllofikkaoijcjjogjnlpfpdccogkhagfghofjaiooplmimanakofkplmofihlkofjaiiogiijaohjkiehagoghofjlloofidip$oglhllofikkaoijcjjogjnlpfegpgpgmfdhehcgjhaengfgohfejhegfgn$oglhllofikkaoijcjjogjnlp$ogiljgofifkfoijcjjogjnlpofjlloofidipfpdbcogkhagfghcacndocaoglhllofikkaoijcjjogjnlpcacndocaogiljgofifkfoijcjjogjnlpofjlloofidipfpdccogkhagfgh$hegpgpgmfdhehcgjhafdgfhagbhcgbhegphcdb$oflhkgoeliikoflalkofkplioikdibofijkkfegpgpgmfdhehcgjhaengfgohfejhegfgn$oflhkgoeliikoflalkofkplioikdibofijkk$oelliooflhkgoeliikohicljoflmiaofkhiloplmimofkpljoflnjdofijinofjlloofidipoilpjloikbimoikdibofiiihoplmimanakoikdibofiiihogioijofjlloofidipofipldoeliiloelokhofkejkoelnjjohjkieojiaipogjiioofidipohlekaofimlkofjpjp$ogjmiaojiaicoflalkofkplioikdibofijkkfegpgpgmfdhehcgjhaengfgohfejhegfgn$ogjmiaojiaicoflalkofkplioikdibofijkk$ofkpljoflnjdofijinofjlloofidipoilpjloikbimoikdibofiiihoplmimoellifoelpjnohjfjjogjmijogjfiiofidipohlekaofimlkofjpjpanakoikdibofiiihogioijofjlloofidipofjljlofjbkiofkejkoelnjjohjkieojiaipogjiioofidipohlekaofimlkofjpjp$hegpgpgmfdhehcgjhafdgfhagbhcgbhegphcdd$ofkplmofihlkdbdaoilpjlofiilgojkcjmoiijlcofialmfegpgpgmfdhehcgjhaengfgohfejhegfgn$ofkplmofihlkdbdaoilpjlofiilgojkcjmoiijlcofialm$ofkplmofihlkoflnjdofijinofjlloofidipohjkieogijiaogjmijofidipohlekaofialmoplmimoelilkdbdaoilpjlofiilgebfcehecoelilc$ofkplmofihlkdbdgoilpjlofiilgojkcjmoiijlcofialmfegpgpgmfdhehcgjhaengfgohfejhegfgn$ofkplmofihlkdbdgoilpjlofiilgojkcjmoiijlcofialm$ofkplmofihlkoflnjdofijinofjlloofidipohjkieogijiaogjmijofidipohlekaofialmoplmimoelilkdbdgoilpjlofiilgebfcehecoelilc$hegpgpgmfdhehcgjhafdgfhagbhcgbhegphcdg$oflalkofkpliohlmkjogjelofegpgpgmfdhehcgjhaengfgohfejhegfgn$oflalkofkpliohlmkjogjelo$cehegigjhdcoejgdgpgo$eggphcgndb$ca";
        private static string[] StringDatas104A = null;
        
        private static string Decodex102(int index105)
        {
            if (StringDatas104A == null) StringDatas104A = StringDatas104.Split((char)(',' - 8));    // '$'
            string data = StringDatas104A[index105];
            data = EncoderXXX.DecodeAlphabet(data);
            return data;
        }


        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name=Decodex102(0)>如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PngSplit_mainForm));
            this.panel = new System.Windows.Forms.Panel();
            this.listBox = new System.Windows.Forms.ListBox();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.全部导出蒙板ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.左上尺寸裁切ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.最适尺寸裁切ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.合并蒙板图像ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.提取较小资源ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.导出两倍尺寸ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.导出所有子图ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.导出子图区域ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.导出精简数据ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.导出遮罩图像ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.导出图像ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.添加蒙板ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.左上尺寸裁剪ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.最适尺寸裁剪ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.导出10进制颜色值ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.导出16进制颜色值ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.尺寸缩放ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.AllowDrop = true;
            this.panel.Controls.Add(this.listBox);
            this.panel.Controls.Add(this.pictureBox);
            this.panel.Location = new System.Drawing.Point(0, 0);
            this.panel.Name = Decodex102(1);
            this.panel.Size = new System.Drawing.Size(519, 400);
            this.panel.TabIndex = 85;
            this.panel.DragDrop += new System.Windows.Forms.DragEventHandler(this.panel_DragDrop);
            this.panel.DragEnter += new System.Windows.Forms.DragEventHandler(this.panel_DragEnter);
            // 
            // listBox
            // 
            this.listBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.listBox.ContextMenuStrip = this.contextMenuStrip2;
            this.listBox.FormattingEnabled = true;
            this.listBox.ItemHeight = 12;
            this.listBox.Location = new System.Drawing.Point(400, 0);
            this.listBox.Name = Decodex102(2);
            this.listBox.Size = new System.Drawing.Size(120, 400);
            this.listBox.TabIndex = 87;
            this.listBox.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.全部导出蒙板ToolStripMenuItem,
            this.左上尺寸裁切ToolStripMenuItem,
            this.最适尺寸裁切ToolStripMenuItem,
            this.toolStripSeparator4,
            this.合并蒙板图像ToolStripMenuItem,
            this.提取较小资源ToolStripMenuItem,
            this.toolStripSeparator5,
            this.导出两倍尺寸ToolStripMenuItem});
            this.contextMenuStrip2.Name = Decodex102(3);
            this.contextMenuStrip2.Size = new System.Drawing.Size(149, 148);
            // 
            // 全部导出蒙板ToolStripMenuItem
            // 
            this.全部导出蒙板ToolStripMenuItem.Name = Decodex102(4);
            this.全部导出蒙板ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.全部导出蒙板ToolStripMenuItem.Text = Decodex102(5);
            this.全部导出蒙板ToolStripMenuItem.ToolTipText = Decodex102(6);
            this.全部导出蒙板ToolStripMenuItem.Click += new System.EventHandler(this.全部导出蒙板ToolStripMenuItem_Click);
            // 
            // 左上尺寸裁切ToolStripMenuItem
            // 
            this.左上尺寸裁切ToolStripMenuItem.Name = Decodex102(7);
            this.左上尺寸裁切ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.左上尺寸裁切ToolStripMenuItem.Text = Decodex102(8);
            this.左上尺寸裁切ToolStripMenuItem.ToolTipText = Decodex102(9);
            this.左上尺寸裁切ToolStripMenuItem.Click += new System.EventHandler(this.左上尺寸裁切ToolStripMenuItem_Click);
            // 
            // 最适尺寸裁切ToolStripMenuItem
            // 
            this.最适尺寸裁切ToolStripMenuItem.Name = Decodex102(10);
            this.最适尺寸裁切ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.最适尺寸裁切ToolStripMenuItem.Text = Decodex102(11);
            this.最适尺寸裁切ToolStripMenuItem.ToolTipText = Decodex102(12);
            this.最适尺寸裁切ToolStripMenuItem.Click += new System.EventHandler(this.最适尺寸裁切ToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = Decodex102(13);
            this.toolStripSeparator4.Size = new System.Drawing.Size(145, 6);
            // 
            // 合并蒙板图像ToolStripMenuItem
            // 
            this.合并蒙板图像ToolStripMenuItem.Name = Decodex102(14);
            this.合并蒙板图像ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.合并蒙板图像ToolStripMenuItem.Text = Decodex102(15);
            this.合并蒙板图像ToolStripMenuItem.ToolTipText = Decodex102(16);
            this.合并蒙板图像ToolStripMenuItem.Click += new System.EventHandler(this.合并蒙板图像ToolStripMenuItem_Click);
            // 
            // 提取较小资源ToolStripMenuItem
            // 
            this.提取较小资源ToolStripMenuItem.Name = Decodex102(17);
            this.提取较小资源ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.提取较小资源ToolStripMenuItem.Text = Decodex102(18);
            this.提取较小资源ToolStripMenuItem.ToolTipText = Decodex102(19);
            this.提取较小资源ToolStripMenuItem.Click += new System.EventHandler(this.提取较小资源ToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = Decodex102(20);
            this.toolStripSeparator5.Size = new System.Drawing.Size(145, 6);
            // 
            // 导出两倍尺寸ToolStripMenuItem
            // 
            this.导出两倍尺寸ToolStripMenuItem.Name = Decodex102(21);
            this.导出两倍尺寸ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.导出两倍尺寸ToolStripMenuItem.Text = Decodex102(22);
            this.导出两倍尺寸ToolStripMenuItem.Click += new System.EventHandler(this.导出两倍尺寸ToolStripMenuItem_Click);
            // 
            // pictureBox
            // 
            this.pictureBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox.BackgroundImage = global::PngSplitFunc.Properties.Resources.TransBg;
            this.pictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox.ContextMenuStrip = this.contextMenuStrip1;
            this.pictureBox.Image = global::PngSplitFunc.Properties.Resources.PngSplit_help2;
            this.pictureBox.Location = new System.Drawing.Point(0, 0);
            this.pictureBox.Name = Decodex102(23);
            this.pictureBox.Size = new System.Drawing.Size(400, 400);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox.TabIndex = 82;
            this.pictureBox.TabStop = false;
            this.pictureBox.Click += new System.EventHandler(this.pictureBox_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.导出所有子图ToolStripMenuItem,
            this.导出子图区域ToolStripMenuItem,
            this.导出精简数据ToolStripMenuItem,
            this.toolStripSeparator2,
            this.导出遮罩图像ToolStripMenuItem,
            this.导出图像ToolStripMenuItem,
            this.添加蒙板ToolStripMenuItem,
            this.toolStripSeparator1,
            this.左上尺寸裁剪ToolStripMenuItem,
            this.最适尺寸裁剪ToolStripMenuItem,
            this.toolStripSeparator3,
            this.导出10进制颜色值ToolStripMenuItem,
            this.导出16进制颜色值ToolStripMenuItem,
            this.toolStripSeparator6,
            this.尺寸缩放ToolStripMenuItem});
            this.contextMenuStrip1.Name = Decodex102(24);
            this.contextMenuStrip1.Size = new System.Drawing.Size(175, 292);
            // 
            // 导出所有子图ToolStripMenuItem
            // 
            this.导出所有子图ToolStripMenuItem.Name = Decodex102(25);
            this.导出所有子图ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.导出所有子图ToolStripMenuItem.Text = Decodex102(26);
            this.导出所有子图ToolStripMenuItem.ToolTipText = Decodex102(27);
            this.导出所有子图ToolStripMenuItem.Click += new System.EventHandler(this.导出所有子图ToolStripMenuItem_Click);
            // 
            // 导出子图区域ToolStripMenuItem
            // 
            this.导出子图区域ToolStripMenuItem.Name = Decodex102(28);
            this.导出子图区域ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.导出子图区域ToolStripMenuItem.Text = Decodex102(29);
            this.导出子图区域ToolStripMenuItem.ToolTipText = Decodex102(30);
            this.导出子图区域ToolStripMenuItem.Click += new System.EventHandler(this.导出子图区域ToolStripMenuItem_Click);
            // 
            // 导出精简数据ToolStripMenuItem
            // 
            this.导出精简数据ToolStripMenuItem.Name = Decodex102(31);
            this.导出精简数据ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.导出精简数据ToolStripMenuItem.Text = Decodex102(32);
            this.导出精简数据ToolStripMenuItem.ToolTipText = Decodex102(33);
            this.导出精简数据ToolStripMenuItem.Click += new System.EventHandler(this.导出精简数据ToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = Decodex102(34);
            this.toolStripSeparator2.Size = new System.Drawing.Size(171, 6);
            // 
            // 导出遮罩图像ToolStripMenuItem
            // 
            this.导出遮罩图像ToolStripMenuItem.Name = Decodex102(35);
            this.导出遮罩图像ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.导出遮罩图像ToolStripMenuItem.Text = Decodex102(36);
            this.导出遮罩图像ToolStripMenuItem.ToolTipText = Decodex102(37);
            this.导出遮罩图像ToolStripMenuItem.Click += new System.EventHandler(this.导出蒙板图像ToolStripMenuItem_Click);
            // 
            // 导出图像ToolStripMenuItem
            // 
            this.导出图像ToolStripMenuItem.Name = Decodex102(38);
            this.导出图像ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.导出图像ToolStripMenuItem.Text = Decodex102(39);
            this.导出图像ToolStripMenuItem.ToolTipText = Decodex102(40);
            this.导出图像ToolStripMenuItem.Click += new System.EventHandler(this.导出图像ToolStripMenuItem_Click);
            // 
            // 添加蒙板ToolStripMenuItem
            // 
            this.添加蒙板ToolStripMenuItem.CheckOnClick = true;
            this.添加蒙板ToolStripMenuItem.Name = Decodex102(41);
            this.添加蒙板ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.添加蒙板ToolStripMenuItem.Text = Decodex102(42);
            this.添加蒙板ToolStripMenuItem.ToolTipText = Decodex102(43);
            this.添加蒙板ToolStripMenuItem.CheckStateChanged += new System.EventHandler(this.添加蒙板ToolStripMenuItem_CheckStateChanged);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = Decodex102(44);
            this.toolStripSeparator1.Size = new System.Drawing.Size(171, 6);
            // 
            // 左上尺寸裁剪ToolStripMenuItem
            // 
            this.左上尺寸裁剪ToolStripMenuItem.Name = Decodex102(45);
            this.左上尺寸裁剪ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.左上尺寸裁剪ToolStripMenuItem.Text = Decodex102(46);
            this.左上尺寸裁剪ToolStripMenuItem.ToolTipText = Decodex102(47);
            this.左上尺寸裁剪ToolStripMenuItem.Click += new System.EventHandler(this.左上尺寸裁剪ToolStripMenuItem_Click);
            // 
            // 最适尺寸裁剪ToolStripMenuItem
            // 
            this.最适尺寸裁剪ToolStripMenuItem.Name = Decodex102(48);
            this.最适尺寸裁剪ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.最适尺寸裁剪ToolStripMenuItem.Text = Decodex102(49);
            this.最适尺寸裁剪ToolStripMenuItem.ToolTipText = Decodex102(50);
            this.最适尺寸裁剪ToolStripMenuItem.Click += new System.EventHandler(this.最适尺寸裁剪ToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = Decodex102(51);
            this.toolStripSeparator3.Size = new System.Drawing.Size(171, 6);
            // 
            // 导出10进制颜色值ToolStripMenuItem
            // 
            this.导出10进制颜色值ToolStripMenuItem.Name = Decodex102(52);
            this.导出10进制颜色值ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.导出10进制颜色值ToolStripMenuItem.Text = Decodex102(53);
            this.导出10进制颜色值ToolStripMenuItem.ToolTipText = Decodex102(54);
            this.导出10进制颜色值ToolStripMenuItem.Click += new System.EventHandler(this.导出10进制颜色值ToolStripMenuItem_Click);
            // 
            // 导出16进制颜色值ToolStripMenuItem
            // 
            this.导出16进制颜色值ToolStripMenuItem.Name = Decodex102(55);
            this.导出16进制颜色值ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.导出16进制颜色值ToolStripMenuItem.Text = Decodex102(56);
            this.导出16进制颜色值ToolStripMenuItem.ToolTipText = Decodex102(57);
            this.导出16进制颜色值ToolStripMenuItem.Click += new System.EventHandler(this.导出16进制颜色值ToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = Decodex102(58);
            this.toolStripSeparator6.Size = new System.Drawing.Size(171, 6);
            // 
            // 尺寸缩放ToolStripMenuItem
            // 
            this.尺寸缩放ToolStripMenuItem.Name = Decodex102(59);
            this.尺寸缩放ToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.尺寸缩放ToolStripMenuItem.Text = Decodex102(60);
            this.尺寸缩放ToolStripMenuItem.Click += new System.EventHandler(this.尺寸缩放ToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 400);
            this.Controls.Add(this.panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject(Decodex102(61))));
            this.MaximizeBox = false;
            this.Name = Decodex102(62);
            this.Text = Decodex102(63);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel.ResumeLayout(false);
            this.contextMenuStrip2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 导出遮罩图像ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 添加蒙板ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 导出图像ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem 导出子图区域ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 导出精简数据ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 导出所有子图ToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem 全部导出蒙板ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem 左上尺寸裁剪ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 最适尺寸裁剪ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 左上尺寸裁切ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 最适尺寸裁切ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem 导出10进制颜色值ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 导出16进制颜色值ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem 合并蒙板图像ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 提取较小资源ToolStripMenuItem;
        private System.Windows.Forms.ListBox listBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem 导出两倍尺寸ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem 尺寸缩放ToolStripMenuItem;
    }
}


