﻿
using SciPay;
using SciUpdate;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PngSplitFunc
{
    public partial class PngSplit_mainForm : Form
    {
        private static string StringDatas103 = "fagoghfdhagmgjheca$hdgpggheeogbgngf$gbhfhegigphceogbgngf$$gihehehahddkcpcphdgdgjgngfgogdgfcoghgjhegfgfcogjgpcpgdgpgogggjghcpgggjgmgfhdcpgdgpgogggjghcohehihe$fbhcfagbhjfdgfhchggfhcebgegehcgfhdhd$fagoghfdhagmgjhe$hdgdgjgngfgogdgf$oelnlpohjekioijcjjogjnlpofkeieohjaigofjlloofidipoelikncococo$oijcjjogjnlpofjlloofidipohjejpogiijaoelikncococo$ofkplmofihlkoijcjjogjnlp$fpdbcogkhagfgh$fpdccogkhagfgh$ogiijaofikjpofkplmofihlkoijcjjogjnlpoplmib$oikplhofifiiogiljgofifkfoijcjjogjnlpofjlloofidipfpdbcogkhagfgh$ofjlloofidipofkplmofihlkoelikncococo$cohagogh$oijcjjogjnlpofjaiiogiijaofjlloofidip$ogiijaofikjpofkplmofihlkofjlloofidip$cm$dlanak$ofknjaofjlloofimlkofjpjpfp$co$fp$ofkplmofihlkogjflaoginkofm$dl$ofknjaofjlloofimlkofjpjpohlcloohkoiafp$ogickiojjmiaoikgibofifiiofkoimogiijaogldkiofigimcmogijinoiidlnoelnlpohjekiogknkeofikjpoiidln$oilnkpoelllgogldkiofigim$ofknjaofjllofp$ogiijaofikjpofkplmofihlkoflnjdofijinofjlloohijihogijiaogjmijofknjaofjllo$gfhigbgnhagmgfcohagogh$ofjlloofidip$cmoikdibofiiihoelikncococo$cogkhagh$cogkhagfgh$ogjmiaojiaicoflalkofkplioikdibofiiih$oflhkgoeliikoflalkofkplioikdibofiiih$ofjlloofidipoikdibofiiihofkoimogiijaoplmib$ogijiaogjmijofjlloofidipoikdibofiiihofkoimogiijaoplmib$cmofidipohlekaogjflaoginkoofkplmofihlkoelikncococo$oilpjlofiilgojkcjmoiijlcofialmfp$gihehehadkcpcpghgjhecogphdgdgigjgogbcogogfhecphdgdgjgngfgogdgfcpfagoghfdhagmgjhe$gjgfhihagmgphcgfcogfhigf$gihehehadkcpcphhhhhhcogcgbgjgehfcogdgpgn$caoikplhogiljgofifkfoflnjdofijinofjlloofidipohjkieoijcjjogjnlpcackfpdccogkhagfghcacococo$ofjaiiofljlgoijcjjogjnlpofjlloofidipoelikncococo$ogiijaofikjpofjaiiofljlgogijiaogjmijoijcjjogjnlpofjlloofidipoplmib$ckfpdbcogkhagfgh$oiloidoflaipofjlloofidipoilfieoglkja$ogiijaofikjpogipjaofipjgoiloidoflaipofjlloofidipoilfieoglkjaoplmib$oelikeofiainoflalkofkpliofjlloofidip$ogiijaofikjpofkplmofihlkoelikeofiainoflalkofkpliofjlloofidip";
        private static string[] StringDatas103A = null;
        
        private static string Decodex101(int index104)
        {
            if (StringDatas103A == null) StringDatas103A = StringDatas103.Split((char)(',' - 8));    // '$'
            string data = StringDatas103A[index104];
            data = EncoderXXX.DecodeAlphabet(data);
            return data;
        }


        string ToolName = Decodex101(0);

        PngSplit_ToolsFunction F = new PngSplit_ToolsFunction();  //图像处理相关函数工具
        string[] buildsPicsName;    //各建筑块名称
        string[] picFiles;          //各建筑块的文件名

        Bitmap picTmp;              //临时存储程序运行过程中处理的图像

        
        private RegisterTool Register = null;
        /// <summary>
        /// 初始化Register
        /// </summary>
        /// <param name=Decodex101(1)>软件名称</param>
        /// <param name=Decodex101(2)>软件作者</param>
        private void InitRegister(string softName, string authorName)
        {
            UpdateTool.SoftName = softName;
            UpdateTool.AuthorName = authorName;
            UpdateTool.AutoUpdate(Decodex101(3), Decodex101(3));

            string QrPayServerAddress = new WebConfiger(Decodex101(4)).Get(Decodex101(5));
            Register = new RegisterTool(QrPayServerAddress, UpdateTool.SoftName, UpdateTool.AuthorName);
        }

        public PngSplit_mainForm()
        {
            InitializeComponent();
            this.Text = ToolName;

            InitRegister(Decodex101(6), Decodex101(7));
        }

        //拖入文件
        private void panel_DragEnter(object sender, DragEventArgs e)
        {
            F.dragEnter(e);
        }
        //放下文件
        private void panel_DragDrop(object sender, DragEventArgs e)
        {
            string filesName = F.dragDrop(e);            //拖入窗体的文件放下
            updatePics(filesName);                       //使用文件对应的建筑图像
        }

        //对拖入的文件进行相应的处理
        private void updatePics(string filesNames)
        {
            //以蒙板的形式添加图像
            if (添加蒙板ToolStripMenuItem.Checked)
            {
                try
                {
                    int index = listBox.SelectedIndex;
                    if (index == -1) return;
                    this.Text = ToolName + Decodex101(8);

                    Image pic = buildsPics(index);             //待添加蒙板的图像
                    picFiles = filesNames.Split(';');          //分割为所有的文件名

                    Image mask = Bitmap.FromFile(picFiles[0]); //蒙板图像

                    picTmp = F.setPicMask(pic, mask);          //添加蒙板到图像上
                    pictureBox.Image = picTmp;                 //临时保存图像

                    添加蒙板ToolStripMenuItem.Checked = false; //添加蒙板完成，清除标识
                    this.Text = ToolName;
                }
                catch (Exception ex)
                { this.Text = ToolName; }
            }
            //添加图像到列表中
            else
            {
                picFiles = filesNames.Split(';');   //分割为所有的文件名

                //获取拖入的建筑块信息
                buildsPicsName = new string[picFiles.Length];

                listBox.Items.Clear();
                for (int i = 0; i < picFiles.Length; i++)
                {
                    buildsPicsName[i] = System.IO.Path.GetFileName(picFiles[i]);    //获取文件名
                    listBox.Items.Add(buildsPicsName[i]);   //添加图像名到列表中
                }

                listBox.SelectedIndex = 0;
            }
        }

        private Bitmap buildsPics(int index)
        {
            return F.ToBitmap(Bitmap.FromFile(picFiles[index])); 
        }

        //显示列表中对应的图像
        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBox.SelectedIndex;  //选择的建筑块图像
            Bitmap pic = buildsPics(index);

            //设置图像的显示样式，大图像拉伸显示、小图像居中显示
            if (pic.Width > pictureBox.Width || pic.Height > pictureBox.Height)
                pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            else pictureBox.SizeMode = PictureBoxSizeMode.CenterImage;

            pictureBox.Image = pic;             //设置当前使用的建筑块图像
        }

        

        Boolean mute = false;
        private void 导出蒙板图像ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                int index = listBox.SelectedIndex;
                if (index == -1) return;
                string name = System.IO.Path.GetFileNameWithoutExtension(buildsPicsName[index]);  //获取文件名
                this.Text = ToolName + Decodex101(9);

                Bitmap[] pic = F.getPicMask(buildsPics(index));

                String subDir = Decodex101(10);
                F.SaveToDirectory(pic[0], name + Decodex101(11), subDir, System.Drawing.Imaging.ImageFormat.Jpeg);
                String Dir = F.SaveToDirectory(pic[1], name + Decodex101(12), subDir, System.Drawing.Imaging.ImageFormat.Jpeg);

                this.Text = ToolName;
                if (!mute) F.MessageWithOpen(Decodex101(13), Dir + name + Decodex101(11));
            }
            catch (Exception ex)
            { this.Text = ToolName; }
        }

        private void 导出图像ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (picTmp == null) MessageBox.Show(Decodex101(14));
            else
            {
                try
                {
                    int index = listBox.SelectedIndex;
                    if (index == -1) return;
                    this.Text = ToolName + Decodex101(15);

                    //获取文件名
                    string name = buildsPicsName[index];
                    if(name.EndsWith(Decodex101(11))) name = name.Remove(name.LastIndexOf(Decodex101(11)));
                    else name = System.IO.Path.GetFileNameWithoutExtension(name);  
                    
                    String Dir = F.SaveToDirectory(picTmp, name + Decodex101(16), Decodex101(17), System.Drawing.Imaging.ImageFormat.Png);

                    this.Text = ToolName;
                    F.MessageWithOpen(Decodex101(18), Dir + name + Decodex101(16));
                }
                catch (Exception ex)
                { this.Text = ToolName; }
            }
        }

        private void 导出子图区域ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int index = listBox.SelectedIndex;
            if (index == -1) return;
            Rectangle[]buildRects = F.GetRects(buildsPics(index));      //获取图像的子图区域

            string str = Decodex101(3);
            for (int i = 0; i < buildRects.Length; i++)
                str += (i.ToString() + Decodex101(19) + buildRects[i].ToString() + (i < buildRects.Length - 1 ? Decodex101(20) : Decodex101(3)));

            string name = Decodex101(21) + buildsPicsName[index].Replace(Decodex101(22), Decodex101(23));
            F.SaveToFile(str, Decodex101(24), name, false);
        }

        private void 导出精简数据ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int index = listBox.SelectedIndex;
            if (index == -1) return;
            Rectangle[] buildRects = F.GetRects(buildsPics(index));     //获取图像的子图区域

            string str = Decodex101(3);
            string str2 = Decodex101(3);
            for (int i = 0; i < buildRects.Length; i++)
            {
                str2 = buildRects[i].X + Decodex101(19) + buildRects[i].Y + Decodex101(19) + buildRects[i].Width + Decodex101(19) + buildRects[i].Height;
                str += (str2 + (i < buildRects.Length - 1 ? Decodex101(25) : Decodex101(3)));
            }

            string name = Decodex101(26) + buildsPicsName[index].Replace(Decodex101(22), Decodex101(23));
            F.SaveToFile(str, Decodex101(24), name, false);
        }

        private void 导出所有子图ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isRegUser = this.Register.IsRegUser();
            if (!isRegUser)
            {
                DialogResult result = MessageBox.Show(Decodex101(27), Decodex101(28), MessageBoxButtons.OKCancel);
                if (result == DialogResult.OK) Register.RegLogic();
            }
            else
            {
                int index = listBox.SelectedIndex;
                if (index == -1) return;
                Rectangle[] buildRects = F.GetRects(buildsPics(index));           //获取图像的子图区域

                //图像的所有子图图像
                Bitmap[] SubPics = new Bitmap[buildRects.Length];
                for (int i = 0; i < buildRects.Length; i++)
                    SubPics[i] = F.GetRect(buildsPics(index), buildRects[i]);     //获取所有子图图像

                string directory = Decodex101(29) + buildsPicsName[index].Replace(Decodex101(22), Decodex101(23));
                string Dir = Decodex101(3);
                for (int i = 0; i < SubPics.Length; i++)       //导出其所有子图
                    Dir = F.SaveToDirectory(SubPics[i], i + Decodex101(16), directory);

                F.MessageWithOpen(Decodex101(30), Dir);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            F.SaveToFile(PngSplitFunc.Properties.Resources.example, Decodex101(31), false);
        }

        private void 全部导出蒙板ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int count = listBox.Items.Count;

            for (int i = 0; i < count; i++ )
            {
                listBox.SelectedIndex = i;
                mute = (i < count-1);
                导出蒙板图像ToolStripMenuItem_Click(null, null);
            }
        }

        private void 左上尺寸裁剪ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clipPic(2);     //截取左上点开始的最小尺寸
        }

        private void 最适尺寸裁剪ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clipPic(1);     //截取最小尺寸
        }
        
        /// <summary>
        /// 根据设定进行图像裁切
        /// </summary>
        private String clipPic(int i)
        {
            int index = listBox.SelectedIndex;
            if (index == -1) return Decodex101(3);
            string name = System.IO.Path.GetFileName(buildsPicsName[index]);//获取文件名
            string Ext = System.IO.Path.GetExtension(name).ToLower();       //获取拓展名
            this.Text = ToolName + Decodex101(32) + name + Decodex101(33);

            int C = 0;
            if(Ext.Equals(Decodex101(34)) || Ext.Equals(Decodex101(35))) C = Color.White.ToArgb(); //jpg图像设置白色为透明色

            Bitmap pic = buildsPics(index);                     //获取图像
            Rectangle Rect = new Rectangle();
            if (i == 1) Rect = F.GetMiniRect(pic, C);           //获取图像pic的最小非透明像素矩形区域
            else if (i == 2) Rect = F.GetMiniLeftRect(pic, C);  //获取从左上点开始的图像pic的最小非透明像素矩形区域

            String subDir = null;
            if (i == 1) subDir = Decodex101(36);
            else if (i == 2) subDir = Decodex101(37);

            pic = F.GetRect(pic, Rect);                         //截取pic中的指定区域Rect
            String Dir = F.SaveToDirectory(pic, name, subDir, (System.Drawing.Imaging.ImageFormat)null); //保存图像到文件

            this.Text = ToolName;
            if (!mute) F.MessageWithOpen(Decodex101(38), Dir + name);
            return Dir;
        }

        private void 左上尺寸裁切ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clipPicAll(2);
        }

        private void 最适尺寸裁切ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clipPicAll(1);
        }

        /// <summary>
        /// 根据设定进行图像裁切
        /// </summary>
        private void clipPicAll(int index)
        {
            int count = listBox.Items.Count;
            if (count == 0) return;

            String Dir = Decodex101(3);
            for (int i = 0; i < count; i++)
            {
                listBox.SelectedIndex = i;
                mute = true;
                Dir = clipPic(index);
            }

            mute = false;
            F.MessageWithOpen(Decodex101(39), Dir);
        }

        private void 导出10进制颜色值ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            getPixelData(10);
        }

        private void 导出16进制颜色值ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            getPixelData(16);
        }

        /// <summary>
        /// 保存当前图像的所有像素颜色值为toBase进制
        /// </summary>
        private void getPixelData(int toBase)
        {
            int index = listBox.SelectedIndex;
            if (index == -1) return;

            Bitmap pic = buildsPics(index);                 //获取图像
            string picName = System.IO.Path.GetFileName(buildsPicsName[index]);  //获取文件名
            this.Text = ToolName + Decodex101(32) + picName + Decodex101(40);

            String str = F.getPixelsData(pic, toBase);      //获取当前显示图像的所有像素颜色值数据
            string name = toBase + Decodex101(41) + picName.Replace(Decodex101(22), Decodex101(23));
            this.Text = ToolName;
            F.SaveToFile(str, Decodex101(24), name, false);  //保存数据到文件
        }

        /// <summary>
        /// 打开工具界面
        /// </summary>
        private void pictureBox_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(Decodex101(42));

            //创建新的进程，打开指定网页
            //System.Diagnostics.Process process = new System.Diagnostics.Process();
            //process.StartInfo.FileName = Decodex101(43);            //IE浏览器，可以更换
            //process.StartInfo.Arguments = Decodex101(44);
            //process.Start();
        }

        private void 添加蒙板ToolStripMenuItem_CheckStateChanged(object sender, EventArgs e)
        {
            bool select = 添加蒙板ToolStripMenuItem.Checked;
            this.Text = ToolName + (select ? Decodex101(45) : Decodex101(3));
        }

        private void 合并蒙板图像ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (picFiles == null) return;

            List<String> picsName = new List<string>();
            foreach (String name in picFiles) picsName.Add(name);

            this.Text = ToolName + Decodex101(46);
            String Dir = Decodex101(3);
            while (picsName.Count > 0)
            {
                String name1 = picsName.ElementAt(0), name2 = Decodex101(3);
                picsName.Remove(name1);

                //获取同名蒙板图像
                if(name1.EndsWith(Decodex101(11))) name2 = name1.Remove(name1.LastIndexOf(Decodex101(11))) + Decodex101(12);
                else if (name1.EndsWith(Decodex101(12))) name2 = name1.Remove(name1.LastIndexOf(Decodex101(12))) + Decodex101(11);

                //合并蒙板图像
                if (picsName.Contains(name2))
                {
                    picsName.Remove(name2);
                    Dir = comeBine(name1, name2);    
                }
            }

            this.Text = ToolName;
            F.MessageWithOpen(Decodex101(47), Dir);
        }

        //从工具导出的蒙板图像,合成png, pic1和pic2名称为Decodex101(48)或Decodex101(48)
        private String comeBine(String pic1, String pic2)
        {
            String Dir = Decodex101(3);

            bool ext_1 = pic1.EndsWith(Decodex101(11));
            String name = System.IO.Path.GetFileName(pic1);
            name = name.Remove(name.LastIndexOf(Decodex101(23)));

            Image pic = Bitmap.FromFile(ext_1 ? pic1 : pic2);   //待添加蒙板的图像
            Image mask = Bitmap.FromFile(ext_1 ? pic2 : pic1);  //蒙板图像

            picTmp = F.setPicMask(pic, mask);                   //添加蒙板到图像上
            Dir = F.SaveToDirectory(picTmp, name + Decodex101(16), Decodex101(17), System.Drawing.Imaging.ImageFormat.Png);
            
            return Dir;
        }

        private void 提取较小资源ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //获取(原图像 和 蒙板图像)较小文件，形成列表
            List<string>[] List = getMiniCopyList();

            //复制图像资源
            for (int i = 0; i < List.Length; i++)
            {
                while (List[i].Count > 0)
                {
                    string file = List[i].ElementAt(0);
                    string name = System.IO.Path.GetFileName(file);

                    if (i == 1) name = name.Remove(name.LastIndexOf(Decodex101(23))) + Decodex101(34);
                    System.IO.File.Copy(file, F.getCurDir(Decodex101(49)) + name, true);
                    List[i].RemoveAt(0);
                }
            }

            F.MessageWithOpen(Decodex101(50), F.getCurDir(Decodex101(49)));
        }

        /// <summary>
        /// 在当前载入的所有图像中，比较原图和其对应的蒙板图像的大小，保留较小的文件名到list中
        /// </summary>
        private List<string>[] getMiniCopyList()
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            Dictionary<string, string> dic_1 = new Dictionary<string, string>();
            Dictionary<string, string> dic_2 = new Dictionary<string, string>();
            List<String> list = new List<string>();     //待复制的原图像或png蒙板图像
            List<String> list_1 = new List<string>();     //待复制的原图像或png蒙板图像

            //资源按文件名分类存储
            foreach (string file in picFiles)
            {
                string name = System.IO.Path.GetFileName(file);
                if (name.EndsWith(Decodex101(11)) || name.EndsWith(Decodex101(12)))
                    name = name.Remove(name.LastIndexOf(Decodex101(23)));
                else name = System.IO.Path.GetFileNameWithoutExtension(name);

                if (file.EndsWith(Decodex101(11))) dic_1.Add(name, file);
                else if (file.EndsWith(Decodex101(12))) dic_2.Add(name, file);
                else dic.Add(name, file);
            }

            //保留较小资源（原图像、蒙板图像）
            while (dic.Count > 0)
            {
                KeyValuePair<string, string> iteam = dic.ElementAt(0);

                Boolean isPng = iteam.Value.EndsWith(Decodex101(16));
                if (dic_1.ContainsKey(iteam.Key) && dic_2.ContainsKey(iteam.Key))   //png图像，比较大小，复制值原图或蒙板图像
                {
                    long len = new System.IO.FileInfo(iteam.Value).Length;
                    long len_1 = new System.IO.FileInfo(dic_1[iteam.Key]).Length;
                    long len_2 = !isPng ? 0 : new System.IO.FileInfo(dic_2[iteam.Key]).Length;

                    //原图像较小
                    if (len <= len_1 + len_2) list.Add(iteam.Value); 
                    else
                    {
                        //png图像，复制其对应的两张蒙板图像
                        if (isPng)  
                        {
                            list.Add(dic_1[iteam.Key]);
                            list.Add(dic_2[iteam.Key]);
                        }
                        //其他图像，近复制蒙板图像_1.jpeg
                        else list_1.Add(dic_1[iteam.Key]);
                    }
                }
                else list.Add(iteam.Value);

                dic.Remove(iteam.Key);
                if (dic_1.ContainsKey(iteam.Key)) dic_1.Remove(iteam.Key);
                if (dic_2.ContainsKey(iteam.Key)) dic_2.Remove(iteam.Key);
            }

            //其他资源
            while (dic_1.Count > 0)
            {
                KeyValuePair<string, string> iteam = dic_1.ElementAt(0);
                list.Add(iteam.Value);
                dic_1.Remove(iteam.Key);
            }

            while (dic_2.Count > 0)
            {
                KeyValuePair<string, string> iteam = dic_2.ElementAt(0);
                list.Add(iteam.Value);
                dic_2.Remove(iteam.Key);
            }

            return new List<string>[]{ list, list_1 };
        }

        private void 导出两倍尺寸ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            String Dir = Decodex101(3);
            foreach (string file in picFiles)
            {
                Image pic = Bitmap.FromFile(file);
                string name = System.IO.Path.GetFileName(file);
                pic = F.shrinkTo(pic, 2);
                Dir = F.SaveToDirectory(pic, name, Decodex101(51));
            }

            F.MessageWithOpen(Decodex101(52), Dir);
        }

        private void 尺寸缩放ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isRegUser = this.Register.IsRegUser();
            if (!isRegUser)
            {
                DialogResult result = MessageBox.Show(Decodex101(27), Decodex101(28), MessageBoxButtons.OKCancel);
                if (result == DialogResult.OK) Register.RegLogic();
            }
            else
            {
                int index = listBox.SelectedIndex;
                PngSplit_ShrinkFrom.imge = buildsPics(index);
                PngSplit_ShrinkFrom.fileName = System.IO.Path.GetFileNameWithoutExtension(buildsPicsName[index]);

                Form form = new PngSplit_ShrinkFrom();
                form.StartPosition = FormStartPosition.CenterParent;
                form.ShowDialog();
            }
        }

    }
}

