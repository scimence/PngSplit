﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace PngSplit
{
    static class Program
    {
        ///// <summary>
        ///// 应用程序的主入口点。
        ///// </summary>
        //[STAThread]
        //static void Main()
        //{
        //    Application.EnableVisualStyles();
        //    Application.SetCompatibleTextRenderingDefault(false);
        //    Application.Run(new Form1());
        //}

        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            DllTool.LoadResourceDll();                // 载入依赖dll
            _Main();
        }

        static void _Main()
        {
            SciUpdate.RunningExceptionTool.Run(call);   // 调用异常信息捕获类，进行异常信息的捕获
        }

        // 应用程序，入口逻辑
        public static void call(string[] args)
        {
            //UpdateTool.AutoUpdate();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Application.Run(new PngSplitFunc.PngSplit_mainForm());
        }
    }
}
